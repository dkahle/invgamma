library(testthat)
library(bqror)

test_check("bqror")