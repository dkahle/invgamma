#' Nivolumab KM data used for reconstructing PFS KM curve
#'
#' Kaplan-Meier (KM) survival data for the experimental arm (nivolumab) extracted from a published figure using PlotDigitizer. This dataset is used to reconstruct the progression-free survival (PFS) KM curve in the CheckMate 017 study.
#'
#' @format A data frame with two variables:
#' \describe{
#'   \item{time}{Numeric. Time points (in months).}
#'   \item{survival}{Numeric. Estimated survival probabilities at corresponding time points.}
#' }
#' @usage data(Experimental)
#' @examples
#' data(Experimental)
#' head(Experimental)
"Experimental"
