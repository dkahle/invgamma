# GCPBayes 4.2.0

## New features

* The problem of running HS_function for genes with 2 SNPs is solved.

* A C++ script is added to run HS_function faster.

* The descriptions of all functions have been updated.

* The second reference to the paper in RJournal has been corrected.

* The URL of the GitHub page has been added.

* The maintainer is changed. An e-mail from the previous maintainer sent to the CRAN admin for explaining the intention to change the maintainer. For contacting the previous maintainer you could send email to t.baghfalaki@gmail.com

* Authors names and their contributions are added.


# GCPBayes 4.1.0

## New features

* Addition of C++ script in order to run DS function faster.  

* The DS could now be run in a faster time.

