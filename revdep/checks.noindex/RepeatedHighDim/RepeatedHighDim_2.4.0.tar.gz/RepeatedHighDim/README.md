A working copy of RepeatedHighDim.
Might not be the same copy as the CRAN version.
Please use the CRAN-version: https://cran.r-project.org/web/packages/RepeatedHighDim/index.html
This Version is experimental.
