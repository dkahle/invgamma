library(testthat)
library(ashr)
context("ashr")
test_check("ashr")
