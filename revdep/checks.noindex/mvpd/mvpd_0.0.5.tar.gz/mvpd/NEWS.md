# mvpd 0.0.5

* add dmvss_mat(). this function may be faster than dmvss() and can handle matrix inputs
* add dmvt_mat(). this is a developmental multivariate t distribution
* add [pr]mvlogis
* add [dr]kolm
* check out the package website that has a deeper dive on some topics
* https://swihart.github.io/mvpd/index.html

# mvpd 0.0.4

* fixed roxygen token
* changed reverse depends from libstableR to libstable4u

# mvpd 0.0.3

* Improved help pages for fit_mvss and rmvss
* Added more tests

# mvpd 0.0.2

* Added multivariate subgaussian stable capabilities

# mvpd 0.0.1

* Added a `NEWS.md` file to track changes to the package.
